<template>
    <div>
      <p>Footer 01023456789 대전광역시 유성구 덕명동</p>
    </div>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style scoped>
  *{
      background-color:#1F1F1F;
      height: 100px;
      color:white;
  }
</style>
