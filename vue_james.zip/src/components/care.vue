<template>
  <section>
    <div>
        이곳은 실내케어 를 볼 수 있는 공간입니다.
        뭐가들어갈진 나도 모릅니다.<br>
        이곳은 실내케어를 볼 수 있는 공간입니다.
        뭐가들어갈진 나도 모릅니다.<br>
        이곳은 실내케어 를 볼 수 있는 공간입니다.
        뭐가들어갈진 나도 모릅니다.

    </div>
  </section>
</template>

<script>
export default {

}
</script>

<style scoped>
    section{
      height: 540px;
      background-color: #F1F2F3;
    }
</style>
